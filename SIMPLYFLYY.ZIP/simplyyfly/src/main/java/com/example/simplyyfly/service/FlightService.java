package com.example.simplyyfly.service;

import com.example.simplyyfly.dto.AddFlightRequest;
import com.example.simplyyfly.dto.FlightResponse;
import com.example.simplyyfly.dto.FlightSearchRequest;

import org.springframework.security.core.Authentication;

import java.util.List;

public interface FlightService {
    void addFlight(AddFlightRequest request, Authentication authentication);
    List<FlightResponse> getAllFlights();
    List<FlightResponse> searchFlights(FlightSearchRequest request);
    void deleteFlight(Long id);
    FlightResponse getFlightById(Long id);
    void updateFlight(Long id, AddFlightRequest request, Authentication authentication);
}
