package com.example.simplyyfly.service;

import com.example.simplyyfly.dto.AddRouteRequest;
import java.util.*;

public interface RouteService {
    void addRoute(AddRouteRequest request);
    List<AddRouteRequest> getAllRoutes();
    void updateRoute(Long id, AddRouteRequest request);
}
