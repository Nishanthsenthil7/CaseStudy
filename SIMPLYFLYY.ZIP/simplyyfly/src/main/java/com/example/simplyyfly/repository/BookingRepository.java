package com.example.simplyyfly.repository;

import com.example.simplyyfly.entity.Booking;
import com.example.simplyyfly.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUser(User user);
}