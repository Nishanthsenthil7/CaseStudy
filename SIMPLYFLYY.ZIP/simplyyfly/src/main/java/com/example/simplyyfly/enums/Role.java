package com.example.simplyyfly.enums;

public enum Role {
    USER,
    FLIGHT_OWNER,
    ADMIN
}
