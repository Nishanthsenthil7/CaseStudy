package com.example.simplyyfly.controller;

import com.example.simplyyfly.dto.AddRouteRequest;
import com.example.simplyyfly.service.RouteService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/routes")
@RequiredArgsConstructor
@Tag(name = "Route Management", description = "Manage air routes and route availability")

public class RouteController {

    private final RouteService routeService;

    @PostMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> addRoute(@RequestBody AddRouteRequest request) {
        routeService.addRoute(request);
        return ResponseEntity.ok("Route added successfully");
    }

    @GetMapping
    public ResponseEntity<List<AddRouteRequest>> getAllRoutes() {
        log.info("GET /api/routes - Fetching all routes");
        return ResponseEntity.ok(routeService.getAllRoutes());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> updateRoute(@PathVariable Long id, @RequestBody AddRouteRequest request) {
        routeService.updateRoute(id, request);
        return ResponseEntity.ok("Route updated successfully");
    }
}

