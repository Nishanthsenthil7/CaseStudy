package com.example.simplyyfly.controller;

import com.example.simplyyfly.dto.BookingRequest;
import com.example.simplyyfly.dto.BookingResponse;
import com.example.simplyyfly.service.BookingService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j //logging
@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@Tag(name = "Booking Management", description = "Book, cancel, and view flight tickets")

public class BookingController {

    private final BookingService bookingService;

    // 🔹 POST /api/bookings → Book a flight
    @PostMapping
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<BookingResponse> bookFlight(@RequestBody BookingRequest request,
                                                      Authentication authentication) {
        log.info("POST /api/bookings called by user: {}", authentication.getName());
        log.debug("BookingRequest: {}", request);
        BookingResponse response = bookingService.bookFlight(request, authentication);
        return ResponseEntity.ok(response);
    }

    // 🔹 GET /api/bookings/my → Get all bookings for the logged-in user
    @GetMapping("/my")
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<List<BookingResponse>> getMyBookings(Authentication authentication) {
        log.info("GET /api/bookings/my called by user: {}", authentication.getName());
        List<BookingResponse> bookings = bookingService.getMyBookings(authentication);
        return ResponseEntity.ok(bookings);
    }

    // 🔹 DELETE /api/bookings/{id} → Cancel a booking
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<String> cancelBooking(@PathVariable Long id,
                                                Authentication authentication) {
        log.info("DELETE /api/bookings/{} called by user: {}", id, authentication.getName());
        String message = bookingService.cancelBooking(id, authentication);
        return ResponseEntity.ok(message);
    }

    // 🔹 GET /api/bookings/all → Admin can view all bookings
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<BookingResponse>> getAllBookings() {
        log.info("GET /api/bookings/all called by admin");
        List<BookingResponse> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }
}
