package com.example.simplyyfly.service;

import com.example.simplyyfly.dto.BookingRequest;
import com.example.simplyyfly.dto.BookingResponse;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface BookingService {
    BookingResponse bookFlight(BookingRequest request, Authentication authentication);
    List<BookingResponse> getMyBookings(Authentication authentication);
    String cancelBooking(Long bookingId, Authentication authentication);
    List<BookingResponse> getAllBookings();
}